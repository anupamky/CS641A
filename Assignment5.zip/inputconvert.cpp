#include<bits/stdc++.h>
using namespace std;

int main()
{
    ifstream ifile;
    ifile.open("inputs.txt");
    ofstream ofile;
    ofile.open("inputs1.txt");

    string s;
    while(ifile>>s)
    {
        ofile<<s<<"\nc\n";
        s.clear();     
    }
}