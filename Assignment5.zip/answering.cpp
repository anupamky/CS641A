#include<bits/stdc++.h>
using namespace std;

int main()
{
    //string s = "ltmjmjlsllmololplomnifififififif";
    //string s = "ltmjmjlsllmololplomnifififififif";
    string s = "mhmjmglqmolgmhlullllifififififif";
    vector<int> a = {114, 116, 113, 107, 121, 97, 114, 111, 102, 102, 48, 48, 48, 48, 48, 48};
    for(auto x:a) cout<<(char)x;
    cout<<endl;
    for(int i=0;i<s.length();i+=2)
    {
        char a=s[i],b=s[i+1];
        int na = a-'f',nb=b-'f';

        int o = na*16+nb;
        //cout<<((char)o);
        cout<<o<<", ";
    }
    cout<<endl;

}