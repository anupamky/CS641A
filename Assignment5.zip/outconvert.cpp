#include<bits/stdc++.h>
using namespace std;

int main()
{
    ifstream ifile;
    ifile.open("final_output.txt");
    ofstream ofile;
    ofile.open("outputs1.txt");

    for(int i=0;i<8;i++)
    {
        for(int j=0;j<128;j++)
        {
            string s;
            ifile>>s;
            ofile<<s<<" ";
        }
        ofile<<"\n";
    }
}